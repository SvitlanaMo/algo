import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private ResizingArrayQueue<Item> rq;

    public RandomizedQueue() {
        this.rq = new ResizingArrayQueue<Item>();
    }

    private class ResizingArrayQueue<Item> {
        private Item[] arr = (Item[]) new Object[2];
        private int size = 0;

        public void push(Item item) {
            if (size == arr.length) resize(2 * arr.length);
            arr[size++] = item;
        }

        public Item popAt(int idx) {
            Item item = arr[idx];
            arr[idx] = null;
            size--;
            if (size > 0 && size == arr.length / 4) resize(arr.length / 2);
            return item;
        }

        public Item getAt(int idx) {
            return arr[idx];
        }

        public int getArrLen() {
            return arr.length;
        }

        public int size() {
            return size;
        }

        private void resize(int capacity) {
            Item[] copy = (Item[]) new Object[capacity];
            int copyIdx = 0;
            for (int i = 0; i < arr.length; i++) {
                if (arr[i] != null) {
                    copy[copyIdx++] = arr[i];
                }
            }
            arr = copy;
        }
    }

    public boolean isEmpty() {
        return this.rq.size() == 0;
    }

    public int size() {
        return this.rq.size();
    }

    public void enqueue(Item item) {
        if (item == null) throw new IllegalArgumentException("can not enqueue with null");
        this.rq.push(item);
    }

    // remove and return a random item
    public Item dequeue() {
        int idx = this.getRandomIdx();
        return rq.popAt(idx);
    }

    // return a random item (but do not remove it)
    public Item sample() {
        int idx = this.getRandomIdx();
        return rq.getAt(idx);
    }

    private int getRandomIdx() {
        int rqSize = this.rq.size();
        if (rqSize == 0) throw new NoSuchElementException("queue is empty");
        int arrLen = rq.getArrLen();
        int idx = StdRandom.uniform(arrLen);
        while (rq.getAt(idx) == null) {
            idx++;
            if (idx >= (arrLen - 1)) idx = 0;
        }
        return idx;
    }

    // return an independent iterator over items in random order
    public Iterator<Item> iterator() {
        return new ListIterator();
    }

    private class ListIterator implements Iterator<Item> {


        public boolean hasNext() {
            return rq.size() != 0;
        }

        public Item next() {
            return dequeue();
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    public static void main(String[] args) {

    }
}
