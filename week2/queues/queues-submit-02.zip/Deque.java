import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {
    private Node first;
    private Node last;
    private int size;

    private class Node {
        private Item data;
        private Node next;
        private Node prev;
    }

    public Deque() {
        first = null;
        last = null;
        size = 0;
    }

    public boolean isEmpty() {
        return this.size == 0;
    }

    public int size() {
        return this.size;
    }

    public void addFirst(Item item) {
        if (item == null) throw new IllegalArgumentException("can not add with null");
        Node newNode = new Node();
        newNode.data = item;
        if (this.isEmpty()) {
            this.first = newNode;
            this.last = newNode;
        }
        else {
            newNode.next = this.first;
            this.first.prev = newNode;
            this.first = newNode;
        }

        this.size++;
    }

    public void addLast(Item item) {
        if (item == null) throw new IllegalArgumentException("can not add with null");
        Node newNode = new Node();
        newNode.data = item;
        if (this.isEmpty()) {
            this.first = newNode;
            this.last = newNode;
        }
        else {
            this.last.next = newNode;
            newNode.prev = this.last;
            this.last = newNode;
        }

        this.size++;
    }

    // remove and return the item from the front
    public Item removeFirst() {
        if (this.isEmpty()) throw new NoSuchElementException("queue is empty");
        Node oldFirstNode = this.first;
        this.first = this.first.next;

        this.size--;
        return oldFirstNode.data;
    }

    // remove and return the item from the end
    public Item removeLast() {
        if (this.isEmpty()) throw new NoSuchElementException("queue is empty");
        Node oldLastNode = this.last;
        this.last = oldLastNode.prev;
        this.size--;
        return oldLastNode.data;

    }

    // return an iterator over items in order from front to end
    public Iterator<Item> iterator() {
        return new ListIterator();
    }

    private class ListIterator implements Iterator<Item> {
        private Node current = first;

        public boolean hasNext() {
            return current != null;
        }

        public Item next() {
            if (!this.hasNext()) throw new NoSuchElementException("no next");

            Item item = current.data;
            current = current.next;
            return item;
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    public static void main(String[] args) {

    }
}
